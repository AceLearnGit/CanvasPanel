﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace CanvasPanel
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public List<PicModel> PicList { get; set; }
        public MainPage()
        {
            this.InitializeComponent();

        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            var list = new List<PicModel>();
            var folder = await StorageFolder.GetFolderFromPathAsync(@"C:\Users\张乾\Pictures\Images");
            var files = await folder.GetFilesAsync();
            foreach (var item in files)
            {
                var p = await item.Properties.GetImagePropertiesAsync();
                list.Add(new PicModel { Width = p.Width, Height = p.Height, ImgPath = item.Path });
            }
            PicList = list;
            this.DataContext = this;
        }

        private void GridView_ItemClick(object sender, ItemClickEventArgs e)
        {

        }

        private void GridView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = e.AddedItems[0];
            var container = gv.ContainerFromItem(item);
        }

        private void gv_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Grid_Tapped(object sender, TappedRoutedEventArgs e)
        {
            var img = sender as Grid;
            var i = img.Children[0];
        }
    }

    public class PicModel : INotifyPropertyChanged
    {

        public uint Width { get; set; }
        public uint Height { get; set; }
        public string ImgPath { get; set; }

        private BitmapImage imgSource;

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string param)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(param));
        }

        public BitmapImage ImgSource
        {
            get
            {
                if (imgSource != null)
                    return imgSource;
                else
                {
                    Task.Run(() => { LoadImg(ImgPath); });
                    return null;
                }

            }
        }

        private async void LoadImg(string path)
        {
            var file = await StorageFile.GetFileFromPathAsync(path);
            var s = await file.OpenAsync(FileAccessMode.Read);
            await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                BitmapImage img = new BitmapImage();
                img.SetSource(s);
                imgSource = img;
                OnPropertyChanged("ImgSource");
            });

        }
    }
}
